CIS*3090 Assignment 4

Description
Write an OpenCL program in C that implements the 1-D Game of Life cellular automaton described by J. Millen.
This algorithm creates an image by calculating one row at a time based upon the previous row.
The image is represented by a two dimensional array.

Group Members
Lavan Raveendrakumar --> 1062897
Shaiza Hashmi --> 1097080
Tinson Wang --> 0983887
Bahaa Zuraik --> 1096463
